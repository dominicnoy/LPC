setwd("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/MEM")
source("Simulate_MEM.R")
Estimate_MEM<-function(As, MEAN_A, method) #MEAN_A from data #output alpha, st, sm)
{   #just for testing
    #As<-Simulate_phase_correction_isochronous(N=50, nseq=100,  a=0.5, st=10, sm=5, random=20) #random is not working
    #MEAN_A<-mean(As)
    
  
    esm=As #-MEAN_A #the mean normalization is not necessary because the model consideres a random intercept
    
    b=esm[2:dim(As)[1],]
    B=esm[1:(dim(As)[1]-1),]
    
    
    
    
    #wide to long | individual sequences are not treated separately
    require(reshape2)
    data<-melt(b); 
    names(data)<-c("n", "nseq", "b")
    data$B<-melt(B)$value 
    
    
    #! If not random effects: use gls! because than I can obtain CIs for all parameters
    #!If random effects: use lme to control for within group variability
    #p230, pinheiro bates
    require(nlme)
    MA1.lme<-lme(b~B, data=data, random=~1|nseq, correlation=corARMA(q=1, form=~1|nseq), method=paste(method))
    #MA1.lme<-lme(b~B, data=data, random=~1|nseq, correlation=corARMA(q=1, form=~1|nseq), method="REML")
    summary(MA1.lme)
    
    #https://www.researchgate.net/profile/Stano_Pekar/publication/304001371_Marginal_Models_Via_GLS_A_Convenient_Yet_Neglected_Tool_for_the_Analysis_of_Correlated_Data_in_the_Behavioural_Sciences/links/5779816e08aeb9427e2c0017/Marginal-Models-Via-GLS-A-Convenient-Yet-Neglected-Tool-for-the-Analysis-of-Correlated-Data-in-the-Behavioural-Sciences.pdf
    #lead to the same result as lme when random effects have var=0
    #demonstration that MA1.lme controls for intertrial variability!
    #Jacoby (check this) suggested to take the OVERALL mean to standardize. (subtract the mean)
    #this would not work when there is intertrialvariability!. this would only work when the mean of each trial
    #is used for standardization.
    #the problem with this approach is that a single trial is really short and actually should not be used for normalization.
    #MA1.gls<-gls(b~B, data=data,corr=corARMA(q=1, form=~1|nseq), method="ML" )
    #summary(MA1.gls)
    #the individual mean normalization could work, but it gets worse the shorter are the time series! 
    
   
    #coef(MA1.gls$modelStruct$corStruct,unconstrained=FALSE)
    
    #summary(MA1.gls)$coef[2]
    
    #obtain parameters
    beta_hat<-summary(MA1.lme)$coefficients$fixed[2]
    theta<-coef(MA1.lme$modelStruct$corStruct,unconstrained=FALSE)
    
    alpha_hat<-1-beta_hat
    sig_e<-summary(MA1.lme)$sigma
    
    #boundary conditions
    #if(theta>0 & beta_hat<0){theta<--theta; beta_hat<--beta_hat}
    #if(theta>0){theta<--theta}
    
    
    
    
    sigM2<--theta*sig_e^2
    sigT2<-sig_e^2*(1-theta^2)-2*sigM2

    sm_hat<-sqrt(sigM2)        
    st_hat<-sqrt(sigT2)
    
    data.frame(alpha_hat, st_hat, sm_hat)
    }


As<-Simulate_MEM(N=50, nseq=100,  a=0.5, st=10, sm=5, random=0)
Estimate_MEM(As,0, "REML")


