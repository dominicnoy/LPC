#N=10; nseq=1; m<-10; st=10; sm=5; alpha=0.5;# range<-sigmaT+2*sigmaM must change
Simulate_MEM<-function(N, nseq, alpha, st, sm, random)
{
  As<-matrix(NA, nrow=N, ncol=nseq)
  for(o in 1:nseq)
  {
    M=rnorm(N+2)
    T=rnorm(N+2)
    
    Z=st*T[1:(N+1)]-sm*M[2:(N+2)]+sm*M[1:(N+1)]
    AA=rep(0,N+2)
    for(I in 1:(N+1))
    {
      AA[I+1]<-(1-alpha)*AA[I]+Z[I]
    }
    As[,o]<-AA[3:(N+2)]+rnorm(1,0,random)
  }
  As
}




