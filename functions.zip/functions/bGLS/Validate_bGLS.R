setwd("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/bGLS")
source("Simulate_bGLS.R")
source("Estimate_bGLS.R")
source("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/aux_functions/multiplot.R")

alphaS=seq(from=0.1, to=2, by=0.1)  #estimate multiple values of alpha
st=sqrt(100)  #parameters chosen according to Vorberg and Schulze (2002) table 1.
sm=sqrt(25)
N=6
nseq=15

MEAN_e=0 #%zero mean since this is simulated... In real data compute it based on maximal amount of possible data avilable

SIMULATION_REPEATS=50 # how many repetitions of the simulation to compute.

# summary variables for estiamtes.
estimates_alpha=matrix(NA, nrow=SIMULATION_REPEATS, ncol=length(alphaS))
estimates_st=matrix(NA, nrow=SIMULATION_REPEATS, ncol=length(alphaS))
estimates_sm=matrix(NA, nrow=SIMULATION_REPEATS, ncol=length(alphaS))

for(KK in 1:SIMULATION_REPEATS)
    { 
      for(I in 1:length(alphaS))
      {
      #I<-1  
      alpha=alphaS[I]
      es=Simulate_bGLS(N, nseq, alpha, st, sm) #simulate data
      results=Estimate_bGLS(es,MEAN_e)
      estimates_alpha[KK,I]<-results$alpha
      estimates_st[KK,I]<-results$st
      estimates_sm[KK,I]<-results$sm
       }
}



###DRAW results
#reshape
##alpha
mean_alpha<-apply(estimates_alpha, 2, function(x) mean(x))
sdt_alpha<-apply(estimates_alpha, 2, function(x) sd(x))
ALPHA<-as.data.frame(cbind(mean_alpha, mean_alpha+qnorm(0.975)*sdt_alpha/sqrt(SIMULATION_REPEATS),mean_alpha-qnorm(0.975)*sdt_alpha/sqrt(SIMULATION_REPEATS), alphaS))
names(ALPHA)<-c("mean", "cl", "cu", "alphaS")
##st
mean_st<-apply(estimates_st, 2, function(x) mean(x))
sdt_st<-apply(estimates_st, 2, function(x) sd(x))
ST<-as.data.frame(cbind(mean_st, mean_st+qnorm(0.975)*sdt_st/sqrt(SIMULATION_REPEATS),mean_st-qnorm(0.975)*sdt_st/sqrt(SIMULATION_REPEATS), alphaS))
names(ST)<-c("mean", "cl", "cu", "alphaS")
##sm
mean_sm<-apply(estimates_sm, 2, function(x) mean(x))
sdt_sm<-apply(estimates_sm, 2, function(x) sd(x))
SM<-as.data.frame(cbind(mean_sm, mean_sm+qnorm(0.975)*sdt_sm/sqrt(SIMULATION_REPEATS),mean_sm-qnorm(0.975)*sdt_sm/sqrt(SIMULATION_REPEATS), alphaS))
names(SM)<-c("mean", "cl", "cu", "alphaS")


#write data
ALPHA$type<-"ALPHA"
SM$type<-"SM"
ST$type<-"ST"
data<-rbind(ALPHA,SM,ST)
data_name<-paste("st",st,"_", "sm",sm,"_", "N",N,"_", "nseq",nseq,".csv",sep="")
write.csv(data, paste("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/data/",data_name, sep=""))






require(ggplot2)
fs<-15
plt_alpha<-ggplot(data[data$type=="ALPHA",], aes(x=alphaS, y=mean)) +
  geom_point()+
  theme_bw() +
  geom_errorbar(aes(ymin=cl, ymax=cu), colour="black", width=.05)+
  #geom_ribbon(data=replication_stationary[replication_stationary$variable=="a_est",], aes(ymin=cl,ymax=cu),alpha=0.3, col="blue")+
  #geom_ribbon(data=replication_stationary[replication_stationary$variable=="a_est",], aes(ymin=mean_score-sqrt(variance),ymax=mean_score+sqrt(variance)),alpha=0.3, col="green")+
  annotate("segment", x=0, xend=2,y=0, yend=2, col="green",linetype=2)+
  theme(axis.line = element_line(colour = "black"),panel.grid.major = element_blank(),panel.grid.minor = element_blank(),panel.background = element_blank(),strip.background = element_blank(),axis.text=element_text(size=fs),axis.title=element_text(size=fs))+
  ylab("hat{Alpha}")+
  xlab("")



ggplot(data[data$type=="ST",], aes(x=alphaS, y=mean)) +
  geom_point()+
  theme_bw() +
  geom_errorbar(aes(ymin=cl, ymax=cu), colour="black", width=.05)+
  #geom_ribbon(data=replication_stationary[replication_stationary$variable=="a_est",], aes(ymin=cl,ymax=cu),alpha=0.3, col="blue")+
  #geom_ribbon(data=replication_stationary[replication_stationary$variable=="a_est",], aes(ymin=mean_score-sqrt(variance),ymax=mean_score+sqrt(variance)),alpha=0.3, col="green")+
  annotate("segment", x=0, xend=2,y=10, yend=10, col="green",linetype=2)+
  ylim(0, 20)+
  theme(axis.line = element_line(colour = "black"),panel.grid.major = element_blank(),panel.grid.minor = element_blank(),panel.background = element_blank(),strip.background = element_blank(),axis.text=element_text(size=fs),axis.title=element_text(size=fs))+
  ylab("hat{Sigma T}")+
  xlab("")


plt_sm<-ggplot(data[data$type=="SM",], aes(x=alphaS, y=mean)) +
  geom_point()+
  theme_bw() +
  geom_errorbar(aes(ymin=cl, ymax=cu), colour="black", width=.05)+
  annotate("segment", x=0, xend=2,y=5, yend=5, col="green",linetype=2)+
  ylim(0, 20)+
  theme(axis.line = element_line(colour = "black"),panel.grid.major = element_blank(),panel.grid.minor = element_blank(),panel.background = element_blank(),strip.background = element_blank(),axis.text=element_text(size=fs),axis.title=element_text(size=fs))+
  ylab("hat{Sigma M}")+
  xlab("Alpha")

#tiff("/Users/mac/Dropbox/MA/MAthesis/thesis/scripts/r replication jacoby2015/plots/replicationjacoby2015_N30_2.jpg", width = 10, height = 8, units = 'in', res = 200)
multiplot(plt_alpha, plt_st, plt_sm, rows=3,cols=1, labs=list("", ""))
#dev.off()


