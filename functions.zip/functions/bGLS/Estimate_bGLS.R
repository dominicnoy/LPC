setwd("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/bGLS")
source("Simulate_bGLS.R") #this is the correct simulation function


Estimate_bGLS<-function(As, MEAN_A) #MEAN_A from data #output alpha, st, sm)
{
    ITER=20
    TRESH=1e-3
    
    N=dim(As)[1]    
    nseq=dim(As)[2]  
    
    #MEAN_A<-mean(As)
    esm=As-MEAN_A  
    
    b=esm[2:N,]
    B=esm[1:(N-1),]
    
    
    alpha_s<-rep(NA, nseq)
    st_s<-rep(NA, nseq)
    sm_s<-rep(NA, nseq)
    
    #forloop for each nseq
    for (KK in 1:nseq)
      {
        #KK<-1
        b1<-b[,KK]
        B1<-B[,KK]
        
        z<-solve(t(B1)%*%B1)%*%t(B1)%*%b1  #not sure, check (in matlab it is mldivide(B1,b1))
        zold<-z
       
        for (II in 1:ITER)
            {
            d=b1-B1*z
            K11<-var(d)
            K12<-cov(d[1:(length(d)-1)], d[2:(length(d))] )
            
            #apply bound of the bGLS
            if(K12>0){K12=0}
            if(K11<3*(-K12)){K11=-3*K12}
            
            #calculate GLS with known covariance
            
            #off diagonal matrix
                mat<-matrix(1, nrow=N-1, ncol=N-1)
                # A companion matrix that indicates how "off" a diagonal is:
                delta <- row(mat) - col(mat)
                
                
                # Set these to select on the "delta" matrix
                low <- -1
                high <- 1
                
                # Operate on the "mat" matrix
                mat[delta < low | delta > high] <-0
                diag(mat)<-0
                mat  
            
            CC<-K11*diag(1, nrow=N-1, ncol=N-1)+K12*mat
            iC<-solve(CC)
            
            z<-solve(t(B1)%*%iC%*%B1)%*%t(B1)%*%iC%*%b1
            
            if(max(abs(z-zold))<TRESH) {break}
            zold=z
            }
        
        alpha_s[KK]<-1-z
        sm_s[KK]<-sqrt(-K12+2.2204e-16)
        st_s[KK]<-sqrt(K11-2*(sm_s[KK]^2))
      }
    
alpha<-mean(alpha_s) 
st<-mean(st_s)    
sm<-mean(sm_s)
out<-data.frame(alpha, st, sm)
names(out)<-c("alpha","st","sm")
out
}

As<-Simulate_bGLS(31, 15, 0.5, 10, 5)
Estimate_bGLS(As,0) 
