N<-10; nseq=15; a=0.5; st=10; sm=5; random=5
As_MEM<-Simulate_MEM(N=N, nseq=nseq,  a=a, st=st, sm=sm, random=random)
As_bGLS<-Simulate_bGLS_RANDOM(N=N, nseq=nseq,  a=a, st=st, sm=sm, random=random)


mbm = microbenchmark::microbenchmark(Estimate_bGLS_RANDOM(As,mean(As)), #use 0 when without random
                   Estimate_bGLS_RANDOM(As_MEM,mean(As_MEM)))
mbm

xtable(mbm)
