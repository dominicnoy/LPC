setwd("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/aux_functions")
source("matrix_inverse.R")
source("off_diag.R")
source("multiplot.R")
source("summarySE.R")

setwd("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/LME")
source("Simulate_LME.R")
source("Estimate_LME.R")


alphaS=seq(from=0.1, to=2, by=0.1)  #estimate multiple values of alpha
st=10  #parameters chosen according to Vorberg and Schulze (2002) table 1.
sm=5
N=6
nseq=15


MEAN_e=0 #%zero mean since this is simulated... In real data compute it based on maximal amount of possible data avilable

# how many repetitions of the simulation to compute.

# summary variables for estiamtes.


BOOT<-50
estimate_BOOT<-list()
for(KK in 1:BOOT)
  {
      #KK<-1 
      estimates=list()
      for(I in 1:length(alphaS))
            {
            #I<-1
            alpha=alphaS[I]
            es=Simulate_LME(N, nseq, alpha, st, sm) #simulate data
            results=LME(es,MEAN_e)
            results<-cbind(results, alphaS[I], nseq, N); names(results)[4:6]<-c("alphas", "N", "nseq")
            estimates[[I]]<-results
            }
      estimates<-do.call(rbind,estimates)
      estimates$boot<-KK
      estimate_BOOT[[KK]]<-estimates
   }


estimates_BOOT<-do.call(rbind, estimate_BOOT)
estimates_BOOT<-estimates_BOOT[complete.cases(estimates_BOOT),]

###DRAW results
mean_est<-aggregate(.~ alphas, estimates_BOOT, FUN = function(x) mean(x))
sd_est<-aggregate(.~ alphas, estimates_BOOT, FUN = function(x) sd(x))

#mean
mean_alphas<-mean_est[,1:2]; names(mean_alphas)<-c("alphas", "mean"); mean_alphas$type<-c("ALPHA")
mean_st<-mean_est[,c(1,3)]; names(mean_st)<-c("alphas", "mean"); mean_st$type<-c("ST")
mean_sm<-mean_est[,c(1,4)]; names(mean_sm)<-c("alphas", "mean"); mean_sm$type<-c("SM")
mean_LME<-rbind(mean_alphas, mean_st, mean_sm)


sd_alphas<-sd_est[,1:2]; names(sd_alphas)<-c("alphas", "sd"); mean_alphas$type<-c("ALPHA")
sd_st<-sd_est[,c(1,3)]; names(sd_st)<-c("alphas", "sd"); mean_st$type<-c("ST")
sd_sm<-sd_est[,c(1,4)]; names(sd_sm)<-c("alphas", "sd"); mean_sm$type<-c("SM")
sd_LME<-rbind(sd_alphas, sd_st, sd_sm)


mean_LME$cl<-mean_LME$mean-qnorm(0.975)*sd_LME$sd/sqrt(BOOT)
mean_LME$cu<-mean_LME$mean+qnorm(0.975)*sd_LME$sd/sqrt(BOOT)


LME_data<-data.frame(mean_LME$mean, mean_LME$cl, mean_LME$cu, mean_LME$alphas, mean_LME$type)
names(LME_data)<-c("mean", "cl", "cu", "alphaS", "type")



data_name<-paste("LME_","st",st,"_", "sm",sm,"_", "N",N,"_", "nseq",nseq,".csv",sep="")
write.csv(LME_data, paste("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/data/LME/",data_name, sep=""))



#estimates_BOOTs<-estimates_BOOT[estimates_BOOT$alphas<=1.2,]  #to compare with old
LME_alpha_standard<-ggplot(LME_data[LME_data$type=="ALPHA",], aes(x=alphaS, y=mean)) +
  geom_point()+
  theme_bw() +
  geom_errorbar(aes(ymin=cl, ymax=cu), colour="black", width=.05)+
  ggtitle("bGLS Normal")+
  annotate("segment", x=0, xend=2,y=0, yend=2, col="green",linetype=2)+
  theme(axis.line = element_line(colour = "black"),panel.grid.major = element_blank(),panel.grid.minor = element_blank(),panel.background = element_blank(),strip.background = element_blank(),axis.text=element_text(size=fs),axis.title=element_text(size=fs))+
  ylab("hat{Alpha}")+
  xlab("")

LME_st_standard<-ggplot(LME_data[LME_data$type=="ST",], aes(x=alphaS, y=mean)) +
  geom_point()+
  theme_bw() +
  geom_errorbar(aes(ymin=cl, ymax=cu), colour="black", width=.05)+
  annotate("segment", x=0, xend=2,y=10, yend=10, col="green",linetype=2)+
  ylim(0, 20)+
  theme(axis.line = element_line(colour = "black"),panel.grid.major = element_blank(),panel.grid.minor = element_blank(),panel.background = element_blank(),strip.background = element_blank(),axis.text=element_text(size=fs),axis.title=element_text(size=fs))+
  ylab("hat{Sigma T}")+
  xlab("")


LME_sm_standard<-ggplot(LME_data[LME_data$type=="SM",], aes(x=alphaS, y=mean)) +
  geom_point()+
  theme_bw() +
  geom_errorbar(aes(ymin=cl, ymax=cu), colour="black", width=.05)+
  annotate("segment", x=0, xend=2,y=5, yend=5, col="green",linetype=2)+
  ylim(0, 20)+
  theme(axis.line = element_line(colour = "black"),panel.grid.major = element_blank(),panel.grid.minor = element_blank(),panel.background = element_blank(),strip.background = element_blank(),axis.text=element_text(size=fs),axis.title=element_text(size=fs))+
  ylab("hat{Sigma M}")+
  xlab("Alpha")


#tiff("/Users/mac/Dropbox/MA/MAthesis/thesis/scripts/r replication jacoby2015/plots/replicationjacoby2015_Pinheiro_N7M15_small.jpg", width = 8, height = 8, units = 'in', res = 200)
multiplot(LME_alpha_standard, LME_st_standard, LME_sm_standard, rows=3, cols=1, labs=list("", ""))
#dev.off()


