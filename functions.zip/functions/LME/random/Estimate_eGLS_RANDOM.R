####Simulate data
#set.seed(1234)
setwd("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/aux_functions")
source("matrix_inverse.R")
source("off_diag.R")
setwd("/Users/mac/Dropbox/MA/MAthesis/thesis/writing/aux/eGLS/random")
source("Simulate_eGLS_RANDOM.R")


eGLS_RANDOM<-function(As, MEAN_A)
{
    ###DATA MINING
      MEAN_A<-mean(As)
      esm=As-MEAN_A  
    
      b=esm[2:dim(As)[1],]
      B=esm[1:(dim(As)[1]-1),]
    
    
      #construct dataframe depending on nseq=1 or >1
      if(dim(data.frame(B))[2]>1){
        require(reshape2)
        data<-melt(b); names(data)<-c("n", "nseq", "b")
        data$B<-melt(B)$value 
      } else {data<-data.frame(c(1:length(b)), rep(1,length(b)), b, B); names(data)<-c("n", "nseq", "b", "B")}
    
    
    
    ###Write alpha_hat as function of lambda
    fun_lambda<-function(lambda)
    {
      #Construct subset LAMBDA
      out<-lapply(split(data, data$nseq), function(x) 
        {
        M<-dim(x)[1]
        #contruct LAMBDA
        diagonal=diag(M)
        offdiagonal=off_diag(M)*lambda
        LAMBDA=diagonal+offdiagonal
        #transformation
        LAMBDA_inv=matrix_inverse(LAMBDA)
        
        y_star<-LAMBDA_inv%*%x$b
        x_star<-LAMBDA_inv%*%x$B
        list(y_star, x_star, LAMBDA)
        })
      
        ###OLS
        #x and y are stacked for OLS  
        x_star<-unlist(lapply(out, `[[`, 1))
        y_star<-unlist(lapply(out, `[[`, 2))
      
        #get each individual LAMBDA
        ind_LAMBDA<-lapply(out, `[[`, 3)
      
        #OLS
        alpha_lambda_hat=solve(t(x_star)%*%x_star)%*%t(x_star)%*%y_star 
      
        #output
        return(list(x_star, y_star, alpha_lambda_hat, ind_LAMBDA))
    }
    
    
    ###PROFILED MAXIMUM LIKELIHOOD
    MLE<-function(lambda)
    {
      #lambda<--0.2
      out<-fun_lambda(lambda)
      
      
      x_star<-out[[1]]
      y_star<-out[[2]]
      M<-length(x_star)
      alpha<-out[[3]]
      ind_LAMBDA<-out[[4]]
      
      LA<-sum(unlist(lapply(ind_LAMBDA, function(x) log(det(x)))))
      return(-(-M*log(sqrt(t(y_star-x_star%*%alpha)%*%(y_star-x_star%*%alpha)))-0.5*LA))
    }
    
    
    lambda_hat<-optim(par=0.1, MLE, 
                      method = c("L-BFGS-B"),
                      lower = -0.5, upper = -0.1)$par
    
    
   
    M<-dim(data)[1]
    #contruct LAMBDA
    diagonal=diag(M)
    offdiagonal=off_diag(M)*lambda_hat
    LAMBDA=diagonal+offdiagonal
    
    #transformation
    LAMBDA_inv=matrix_inverse(LAMBDA)
    y_star<-LAMBDA_inv%*%data$b
    x_star<-LAMBDA_inv%*%data$B
    #OLS
    alpha_hat=1-solve(t(x_star)%*%x_star)%*%t(x_star)%*%y_star 
    #sig_e=(t(y_star-x_star%*%alpha_hat)%*%(y_star-x_star%*%alpha_hat))/(M)
    sig_e<-summary(lm(y_star~x_star))$sigm^2
    
    
    #from bGLS_phase_isochronous_only
    K11<-sig_e
    K12<-sig_e*lambda_hat
    
    #apply bound of the bGLS
    #if(K12>0){K12=0}
    #if(K11<3*(-K12)){K11=-3*K12}
    
    
    sm<-sqrt(-K12+2.2204e-16)
    st<-sqrt(K11-2*(sm^2))
    
    data.frame(alpha_hat, st, sm)  
}


As<-Simulate_eGLS_RANDOM(N=30, nseq=15, alpha=0.1, st=10, sm=5, 5)
eGLS_RANDOM(As, 0)
